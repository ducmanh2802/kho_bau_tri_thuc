export type SubjectType = 'tieng-viet' | 'toan' | 'english';

export type MasteryStatus = 'NOT_STARTED' | 'LEARNING' | 'PRACTICING' | 'MASTERED' | 'NEEDS_REVIEW';

/** Session profiles for the adaptive practice engine. */
export type SessionProfileKind = 'QUICK' | 'STANDARD' | 'DEEP' | 'EXTENDED';

export type QuestionType =
  | 'multiple-choice'
  | 'drag-drop'
  | 'fill-blank'
  | 'matching'
  | 'ordering'
  | 'image-choice'
  | 'audio-choice'
  | 'math-expression'
  | 'true-false';

export interface Question {
  id: string;
  subject: SubjectType;
  topicId: string;
  skillId: string;
  difficulty: 1 | 2 | 3;
  type: QuestionType;
  prompt: string;
  audioPrompt?: string; // Text to be read by TTS
  mediaEmoji?: string;
  options?: string[];
  correctAnswer: string | string[]; // Can be string or array for ordering/matching
  pairs?: { left: string; right: string }[];
  hint?: string;
  explanation?: string;
}

export interface Lesson {
  id: string;
  topicId: string;
  subject: SubjectType;
  title: string;
  description: string;
  mascotTip: string;
  questions: Question[];
  xpReward: number;
  starReward: number;
}

export interface Topic {
  id: string;
  subject: SubjectType;
  title: string;
  subtitle: string;
  iconEmoji: string;
  color: string;
  skills: string[];
  lessons: Lesson[];
}

export interface SkillMastery {
  skillId: string;
  skillName: string;
  subject: SubjectType;
  attempts: number;
  correctCount: number;
  wrongCount: number;
  status: MasteryStatus;
  lastPracticed: string; // ISO string
}

export interface DailyQuest {
  id: string;
  title: string;
  targetCount: number;
  currentCount: number;
  rewardStars: number;
  rewardXp: number;
  completed: boolean;
  type: 'lesson_viet' | 'lesson_math' | 'lesson_english' | 'play_game' | 'daily_review';
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: string;
  xpReward: number;
}

export interface AvatarItem {
  id: string;
  name: string;
  type: 'hat' | 'glasses' | 'shirt' | 'backpack' | 'pet';
  emoji: string;
  priceStars: number;
  unlocked: boolean;
}

export interface ChildProfile {
  id: string;
  name: string;
  grade: number; // 1
  avatarBase: 'bear' | 'fox' | 'rabbit' | 'owl';
  equipped: {
    hat?: string;
    glasses?: string;
    shirt?: string;
    backpack?: string;
    pet?: string;
  };
  xp: number;
  stars: number;
  gems: number;
  tickets: number;
  streak: number;
  lastActiveDate: string;
  unlockedItems: string[];
  completedLessons: string[];
  completedWeeklyChallenges: string[];
  dailyChestClaimedDate?: string;
  /**
   * True when the profile was populated by the parent-only demo seeder.
   * Demo figures are fabricated for showcasing reports and must never be
   * presented to the child (or to parents) as real learner progress.
   */
  isDemoData?: boolean;
}

export interface LearningAnalytics {
  totalMinutesSpent: number;
  minutesToday: number;
  todayDate: string;
  totalQuestionsAnswered: number;
  totalCorrect: number;
  lessonsCompletedCount: number;
  gamesPlayedCount: number;
  skillMastery: Record<string, SkillMastery>;
  recentErrors: {
    questionId: string;
    subject: SubjectType;
    prompt: string;
    timestamp: string;
  }[];
}

export interface ParentSettings {
  dailyLimitMinutes: number; // 10, 15, 20, 30, 0 = unlimited
  soundEnabled: boolean;
  musicEnabled: boolean;
  voiceEnabled: boolean;
  difficultyScale: 'easy' | 'normal' | 'advanced';
  /**
   * Read each question aloud automatically (§20).
   *
   * Default ON with an explicit rationale: the audience is 6-year-olds who are
   * still LEARNING to read, so silent questions lock pre-readers out of the
   * whole app. This is the documented accessibility mode that permits
   * auto-play; a parent can switch it OFF and questions stay behind the
   * user-initiated "Nghe câu hỏi" button. Mute / voice-off still wins.
   */
  questionAutoplay: boolean;
  /**
   * Default practice-session length offered to the child (Adaptive Learning
   * Upgrade). QUICK ≈ 8-10 câu, STANDARD ≈ 15-20, DEEP ≈ 25-30, EXTENDED ≈ 35-40.
   * The child can always pick a shorter session; a parent can lower the default.
   */
  defaultSessionProfile: SessionProfileKind;
  /** Allow L4-L5 challenge questions once prerequisites are demonstrated. */
  allowAdvancedQuestions: boolean;
  /** How much spaced review a session mixes in. */
  reviewIntensity: 'light' | 'standard' | 'intensive';
  /** Offer an explicit break/pause inside long sessions (never force a 6-year-old). */
  optionalBreaks: boolean;
}

/**
 * Per-game level progression (mini-game arcade). `unlockedTier` is the highest
 * tier the child may start, `starsByTier` records the best star result per tier
 * (keyed by tier id, 1..GAME_LEVEL_POLICY.MAX_TIER).
 */
export interface GameLevelProgress {
  unlockedTier: number;
  starsByTier: Record<number, number>;
  bestScoreByTier: Record<number, number>;
  updatedAt: string;
}

/** Versioned store for every game's level progress (own localStorage key). */
export interface GameProgressStore {
  version: number;
  games: Record<string, GameLevelProgress>;
  updatedAt: string;
}

export type ActiveScreen =
  | 'home'
  | 'world_map'
  | 'subject'
  | 'games'
  | 'daily_review'
  | 'reading_fluency'
  | 'weekly_challenge'
  | 'competition'
  | 'achievements'
  | 'avatar_shop'
  | 'kidbox_companion';

export * from './competition';
export * from './reading';
export * from './learningOS';
export * from './decisionEngine';
